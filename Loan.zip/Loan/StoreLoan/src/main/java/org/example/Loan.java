package org.example;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Loan {

    private String loanId;
    private String customerId;
    private String lenderId;
    private double amount;
    private double remainingAmount;
    private LocalDate paymentDate;
    private double interestPerDay;
    private LocalDate dueDate;
    private double penaltyPerDay;

    public Loan(String loanId, String customerId, String lenderId, double amount,
                double remainingAmount, LocalDate paymentDate, double interestPerDay,
                LocalDate dueDate, double penaltyPerDay) {
        this.loanId = loanId;
        this.customerId = customerId;
        this.lenderId = lenderId;
        this.amount = amount;
        this.remainingAmount = remainingAmount;
        this.paymentDate = paymentDate;
        this.interestPerDay = interestPerDay;
        this.dueDate = dueDate;
        this.penaltyPerDay = penaltyPerDay;
    }

    public void validatePaymentDate() {
        if (paymentDate.isAfter(dueDate)) {
            throw new IllegalArgumentException("Payment date can't be greater than the due date.");
        }
    }

    public void checkDueDateCrossed() {
        if (LocalDate.now().isAfter(dueDate)) {
            Logger logger = Logger.getLogger(Loan.class.getName());
            logger.log(Level.WARNING, "Loan with ID " + loanId + " has crossed the due date.");
        }
    }

    public double getRemainingAmount() {
        return remainingAmount;
    }

    public double getInterestAmount() {
        int daysPastDue = LocalDate.now().isAfter(dueDate) ? (int) (LocalDate.now().toEpochDay() - dueDate.toEpochDay()) : 0;
        double interestAmount = remainingAmount * (interestPerDay / 100) * daysPastDue;
        return Math.max(0, interestAmount); // Ensure the interest amount is non-negative
    }

    public double getPenaltyAmount() {
        int daysPastDue = LocalDate.now().isAfter(dueDate) ? (int) (LocalDate.now().toEpochDay() - dueDate.toEpochDay()) : 0;
        double penaltyAmount = remainingAmount * (penaltyPerDay / 100) * daysPastDue;
        return Math.max(0, penaltyAmount); // Ensure the penalty amount is non-negative
    }

    public String getLenderId() {
       return this.lenderId;
    }
}
