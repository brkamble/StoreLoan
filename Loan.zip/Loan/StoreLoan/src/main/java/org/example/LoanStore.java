package org.example;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LoanStore {
//    private List<Loan> loans;
//
//    public LoanStore() {
//        this.loans = new ArrayList<>();
//    }
//
//    public void addLoan(Loan loan) throws Exception {
//        loan.validatePaymentDate();
//        loans.add(loan);
//    }
//
//
//    // Get remaining amount, interest, and penalty aggregated by Lender
//    public Map<String, Map<String, Double>> aggregateByLender() {
//        Map<String, Map<String, Double>> aggregatedData = new HashMap<>();
//
//        for (Loan loan : loans) {
//            String lenderId = loan.getLenderId();
//            double remainingAmount = loan.getRemainingAmount();
//            double interest = calculateInterest(loan);
//            double penalty = calculatePenalty(loan);
//
//            if (!aggregatedData.containsKey(lenderId)) {
//                aggregatedData.put(lenderId, new HashMap<>());
//            }
//
//            Map<String, Double> lenderData = aggregatedData.get(lenderId);
//            lenderData.put("Remaining Amount", lenderData.getOrDefault("Remaining Amount", 0.0) + remainingAmount);
//            lenderData.put("Interest", lenderData.getOrDefault("Interest", 0.0) + interest);
//            lenderData.put("Penalty", lenderData.getOrDefault("Penalty", 0.0) + penalty);
//        }
//
//        return aggregatedData;
//    }
//
//    // Get remaining amount, interest, and penalty aggregated by Interest
//    public Map<Double, Map<String, Double>> aggregateByInterest() {
//        Map<Double, Map<String, Double>> aggregatedData = new HashMap<>();
//
//        for (Loan loan : loans) {
//            double interestPerDay = loan.getInterestPerDay();
//            double remainingAmount = loan.getRemainingAmount();
//            double interest = calculateInterest(loan);
//            double penalty = calculatePenalty(loan);
//
//            if (!aggregatedData.containsKey(interestPerDay)) {
//                aggregatedData.put(interestPerDay, new HashMap<>());
//            }
//
//            Map<String, Double> interestData = aggregatedData.get(interestPerDay);
//            interestData.put("Remaining Amount", interestData.getOrDefault("Remaining Amount", 0.0) + remainingAmount);
//            interestData.put("Interest", interestData.getOrDefault("Interest", 0.0) + interest);
//            interestData.put("Penalty", interestData.getOrDefault("Penalty", 0.0) + penalty);
//        }
//
//        return aggregatedData;
//    }
//
//    // Get remaining amount, interest, and penalty aggregated by Customer ID
//    public Map<String, Map<String, Double>> aggregateByCustomerId() {
//        Map<String, Map<String, Double>> aggregatedData = new HashMap<>();
//
//        for (Loan loan : loans) {
//            String customerId = loan.getCustomerId();
//            double remainingAmount = loan.getRemainingAmount();
//            double interest = calculateInterest(loan);
//            double penalty = calculatePenalty(loan);
//
//            if (!aggregatedData.containsKey(customerId)) {
//                aggregatedData.put(customerId, new HashMap<>());
//            }
//
//            Map<String, Double> customerData = aggregatedData.get(customerId);
//            customerData.put("Remaining Amount", customerData.getOrDefault("Remaining Amount", 0.0) + remainingAmount);
//            customerData.put("Interest", customerData.getOrDefault("Interest", 0.0) + interest);
//            customerData.put("Penalty", customerData.getOrDefault("Penalty", 0.0) + penalty);
//        }
//
//        return aggregatedData;
//    }
//
//    // Helper method to calculate interest for a loan
//    private double calculateInterest(Loan loan) {
//        // Implement the logic to calculate interest based on loan details
//        // For simplicity, let's assume it's a flat interest calculation
//        return loan.getRemainingAmount() * loan.getInterestPerDay();
//    }
//
//    // Helper method to calculate penalty for a loan
//    private double calculatePenalty(Loan loan) {
//        // Implement the logic to calculate penalty based on loan details
//        // For simplicity, let's assume it's a flat penalty calculation
//        return loan.getRemainingAmount() * loan.getPenaltyPerDay();
//    }
//
//    public int getTotalLoans() {
//        return loans.size();
//    }
}
