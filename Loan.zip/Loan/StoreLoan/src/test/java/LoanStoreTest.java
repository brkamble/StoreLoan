import org.example.Loan;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;


public class LoanStoreTest {

    @Test
    public void testValidatePaymentDate_ValidDate() {
        Loan loan = new Loan("L1", "C1", "LEN1", 10000, 10000, LocalDate.of(2023, 5, 6), 0.01,
                LocalDate.of(2023, 5, 7), 0.01);
        Assertions.assertDoesNotThrow(loan::validatePaymentDate);
    }

    @Test
    public void testValidatePaymentDate_InvalidDate() {
        Loan loan = new Loan("L2", "C1", "LEN1", 20000, 5000, LocalDate.of(2023, 6, 1), 0.01,
                LocalDate.of(2023, 5, 8), 0.01);
        Assertions.assertThrows(IllegalArgumentException.class, loan::validatePaymentDate);
    }

    @Test
    public void testGetRemainingAmount() {
        Loan loan = new Loan("L3", "C2", "LEN2", 50000, 30000, LocalDate.of(2023, 4, 4), 0.02,
                LocalDate.of(2023, 4, 5), 0.02);
        Assertions.assertEquals(30000, loan.getRemainingAmount());
    }


    @Test
    public void testGetInterestAmount_PastDue() {
        Loan loan = new Loan("L4", "C3", "LEN2", 50000, 30000, LocalDate.of(2023, 4, 4), 0.02,
                LocalDate.of(2023, 4, 5), 0.02);
        // Assuming the current date is 2023-07-22
        // The loan is past due by 108 days (2023-07-22 - 2023-04-05)
        // Interest: 30000 * (0.02 / 100) * 108 = 648.0
        Assertions.assertEquals(648.0, loan.getInterestAmount(), 0.001);
    }


    @Test
    public void testGetInterestAmount_NoPastDue() {
        Loan loan = new Loan("L3", "C2", "LEN2", 50000, 30000, LocalDate.of(2023, 4, 4), 0.02,
                LocalDate.of(2023, 4, 5), 0.02);
        // No past due, so the interest amount should be 0.0
        Assertions.assertEquals(0.0, loan.getInterestAmount(), 0.001);
    }

    @Test
    public void testGetPenaltyAmount_NoPastDue() {
        Loan loan = new Loan("L3", "C2", "LEN2", 50000, 30000, LocalDate.of(2023, 4, 4), 0.02,
                LocalDate.of(2023, 4, 5), 0.02);
        // No past due, so the penalty amount should be 0.0
        Assertions.assertEquals(0.0, loan.getPenaltyAmount(), 0.001);
    }



    @Test
    public void testGetPenaltyAmount_PastDue() {
        Loan loan = new Loan("L4", "C3", "LEN2", 50000, 30000, LocalDate.of(2023, 4, 4), 0.02,
                LocalDate.of(2023, 4, 5), 0.02);
        // Assuming the current date is 2023-07-22
        // The loan is past due by 108 days (2023-07-22 - 2023-04-05)
        // Penalty: 30000 * (0.02 / 100) * 108 = 648.0
        Assertions.assertEquals(648.0, loan.getPenaltyAmount(), 0.001);
    }

}
